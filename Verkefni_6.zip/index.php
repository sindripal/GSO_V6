<?php 



/*CSV*/
$file = fopen('csv.csv', 'r');
$titles = fgetcsv($file);
$Myndir = [];
while (($data = fgetcsv($file)) !== false) {
    if (count($data) == 1 && is_null($data[0])){
        continue;
    }
    $Myndir[] = array_combine($titles, $data);
}
fclose($file);



/*JSON*/
$jsonData = file_get_contents('./json.json');
$myndir2 = json_decode($jsonData);



/*SQL*/
require_once("connection.php");
include("query.php");



 ?>



<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
        <title>Verkefni 6</title>
        <style>
        table, th , td {
            border: 1px solid grey;
            border-collapse: collapse;
            padding: 5px;
        }
        table tr:nth-child(odd) {
            background-color: #f1f1f1;
        }
        table tr:nth-child(even) {
            background-color: #ffffff;
        }
    </style>
    </head>
    <body>
        <?php
        $selectedCaption = "{$Myndir[0]['MyndHeiti']}";
        $selectedImage = "{$Myndir[0]['MyndSlod']}";
        $selectedCaption2 = "{$Myndir[1]['MyndHeiti']}";
        $selectedImage2 = "{$Myndir[1]['MyndSlod']}";
        $selectedCaption3 = "{$Myndir[2]['MyndHeiti']}";
        $selectedImage3 = "{$Myndir[2]['MyndSlod']}";
        ?>

        <p>CSV</p>

        <h1><?php echo($selectedCaption); ?></h1>
        <img src="<?php echo($selectedImage); ?>" alt="Random image" height="420px" width="420px">
        <h1><?php echo($selectedCaption2); ?></h1>
        <img src="<?php echo($selectedImage2); ?>" alt="Random image" height="420px" width="420px">
        <h1><?php echo($selectedCaption3); ?></h1>
        <img src="<?php echo($selectedImage3); ?>" alt="Random image" height="420px" width="420px">



        <p>JSON</p> 

        <table>
            <?php           
                foreach ($myndir2 as $key => $value) {
                    echo "<tr><th>", $key , "</th><td><img src='", $value , "' width='420px' height='420px'></td></tr>";          
                }
            ?>
        </table>



        <p>SQL</p>

        <table border="1">  
        <tr>
            <th>Image name</th>
            <th>Image</th>
            </tr>
            <?php 
                foreach ($highscores as $entry) {
                    echo '<tr><td>'.$entry[0].'</td><td><img src="'.$entry[1].'" width="420px" height="420px"></td></tr>';
                }
             ?>
        </table>

        <div style="border: 3px solid black; padding: 2px; margin: 2px; width: 500px;">
        <form action="insert.php" method="post">
        <label>Image name: </label>
        <input type="text" name="imageName" required ><br>
        
        <label>Image: </label>
        <input type="text" name="imagePath" required ><br>

        <input type="submit">
    </form>
    </div>

    </body>
</html>